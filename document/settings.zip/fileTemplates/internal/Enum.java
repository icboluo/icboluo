#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
*@author icboluo
*@since ${YEAR}-${MONTH}-${DAY} ${TIME}
*/
public enum ${NAME} {
}
